const nodemailer = require("nodemailer");
// import nodemailer from "nodemailer";

const userGmail = "correoslogiciel@gmail.com";
const passAppGmail = "zwqx eimj hfpt rzcs";

// Set up Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: userGmail,
    pass: passAppGmail,
  },
});

// Define a route for sending emails
// Set up email options
const mailOptions = {
  from: userGmail,
  to: "beautifo.19@gmail.com",
  subject: "Prueba email",
  text: "Hola Lindaaaaaaaaaaaa, esta es la prueba desde js >:)",
};

// Send email
transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
    console.log(error);
  }
  console.log("Email sent: " + info.response);
});